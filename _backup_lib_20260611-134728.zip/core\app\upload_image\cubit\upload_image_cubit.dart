import 'dart:io';

import 'package:chat_material3/core/service/network/api_result.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:chat_material3/core/app/upload_image/repo/upload_image_repo.dart';
import 'package:chat_material3/core/service/image_picker/pick_image_utils.dart';

part 'upload_image_cubit.freezed.dart';
part 'upload_image_state.dart';

class UploadImageCubit extends Cubit<UploadImageState> {
  UploadImageCubit(this._repo) : super(const UploadImageState.initial());

  final UploadImageRepo _repo;

  String getImageUrl = '';

  List<String> imageList = ['', '', ''];
  List<String> imageUpdateList = [];

  // pick image and save it in file and upload it to server
  Future<void> uploadImage() async {
    final pickedImage = await PickImageUtils().pickImage();
    if (pickedImage == null) return;

    emit(const UploadImageState.loading());
    final result = await _repo.uploadImage(image: File(pickedImage.path));

    result.when(
      success: (image) {
        getImageUrl = image.url;

        emit(const UploadImageState.success());
      },
      failure: (error) {
        debugPrint(error);

        emit(UploadImageState.error(error: error));
      },
    );
  }

  // pick image and save it in file and upload it to server with List
  Future<void> uploadImageList({required int indexId}) async {
    final pickedImage = await PickImageUtils().pickImage();
    if (pickedImage == null) return;

    emit(UploadImageState.loadingList(indexId));
    final result = await _repo.uploadImage(image: File(pickedImage.path));

    result.when(
      success: (image) {
        imageList
          ..removeAt(indexId)
          ..insert(indexId, image.storagePath);
        emit(const UploadImageState.success());
      },
      failure: (error) {
        emit(UploadImageState.error(error: error));
      },
    );
  }

  // Upload update image list
  Future<void> uploadUpdateImageList({
    required int indexId,
    required List<String> productImageList,
  }) async {
    final pickedImage = await PickImageUtils().pickImage();
    if (pickedImage == null) return;

    emit(UploadImageState.loadingList(indexId));
    final result = await _repo.uploadImage(image: File(pickedImage.path));

    result.when(
      success: (image) {
        imageUpdateList = productImageList;
        imageUpdateList
          ..removeAt(indexId)
          ..insert(indexId, image.storagePath);
        emit(const UploadImageState.success());
      },
      failure: (error) {
        emit(UploadImageState.error(error: error));
      },
    );
  }

  // remove image

  void removeImage() {
    getImageUrl = '';

    emit(UploadImageState.removeImage(imageUrl: getImageUrl));
  }
}
